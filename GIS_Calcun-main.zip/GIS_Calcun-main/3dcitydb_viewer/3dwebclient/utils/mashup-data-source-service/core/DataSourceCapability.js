var DataSourceCapabilitiy;
(function (DataSourceCapabilitiy) {
    DataSourceCapabilitiy[DataSourceCapabilitiy["READ"] = 0] = "READ";
    DataSourceCapabilitiy[DataSourceCapabilitiy["INSERT"] = 1] = "INSERT";
    DataSourceCapabilitiy[DataSourceCapabilitiy["UPDATE"] = 2] = "UPDATE";
    DataSourceCapabilitiy[DataSourceCapabilitiy["DELETE"] = 3] = "DELETE";
})(DataSourceCapabilitiy || (DataSourceCapabilitiy = {}));
