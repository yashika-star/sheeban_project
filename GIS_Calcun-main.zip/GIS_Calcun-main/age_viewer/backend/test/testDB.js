const connectionForm = {
    'host':"localhost",
    'port':"5432",
    'database':"TEST",
    'user':"TEST",
    'password':"TEST"

}

export {connectionForm};