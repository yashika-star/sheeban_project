For integration tests involving db:
    docker compose up
