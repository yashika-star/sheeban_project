show server_version;
