SELECT * FROM ag_catalog.ag_graph;
